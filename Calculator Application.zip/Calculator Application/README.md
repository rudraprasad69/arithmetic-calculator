# Calculator

A simple Calculator App built with HTML, CSS, and JavaScript. It also has a Dark Mode.

![Calculator Preview Image]()

* Favicon from:
<a href="https://www.flaticon.com/free-icons/calculator" title="calculator icons">Freepik - Flaticon</a>
